# RecyclerViewEffectGather
基于RecyclerView的效果实现： 比如顶部渐变效果

###效果一：RecyclerView滑动顶部渐变的效果

  RecyclerView滑动顶部的文字颜色随着滑动，会逐步变淡的效果，直播聊天室场景运用比较多。

|  | 本项目Demo | 线上运用场景 |
| ------------ | ------------- | ------------ |
| 效果展示 | ![gif](http://s17.mogucdn.com/new1/v1/bmisc/bf9144491db31fd61c1a95b45582bc9b/172576804352.gif)  | ![gif](http://s16.mogucdn.com/new1/v1/bmisc/425e1340fdc232dc13bcfb628f5be309/172578837644.gif) |
